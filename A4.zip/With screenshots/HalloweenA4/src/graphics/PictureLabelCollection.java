package graphics;

public interface PictureLabelCollection extends LabelCollection<PictureLabel>
{

}
