package graphics;

public interface Point
{
	public int getX(); 
	public int getY(); 	
}
