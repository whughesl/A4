package graphics;

public interface CompleteHouseCollection extends LabelCollection<CompleteHouse>
{

}
