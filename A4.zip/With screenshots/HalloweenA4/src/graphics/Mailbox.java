package graphics;

public interface Mailbox extends LineAndShape
{
	public Shape createShape();
}
