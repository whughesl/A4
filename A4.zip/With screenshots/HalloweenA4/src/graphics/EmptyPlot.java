package graphics;

public interface EmptyPlot
{
	public PictureLabel getGrass();
	public PictureLabel getForSaleSign();
	public void setXY(int newLocationX, int newLocationY);
}
