package graphics;

public interface CompleteHouseWithCandyCollection extends LabelCollection<CompleteHouseWithCandy>
{

}
