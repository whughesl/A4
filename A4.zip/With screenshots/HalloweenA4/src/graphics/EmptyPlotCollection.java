package graphics;

public interface EmptyPlotCollection extends LabelCollection<EmptyPlot>
{

}
