/**
 * 
 */
/**
 * @author Dewan
 *
 */
package util.trace.trickOrTreat;