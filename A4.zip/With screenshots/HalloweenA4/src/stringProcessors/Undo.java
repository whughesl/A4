package stringProcessors;

public class Undo extends Word
{
	public Undo(String input)
	{
		super(input, "Command");
	}
}