package stringProcessors;

public class Preset extends Word
{
	public Preset(String input)
	{
		super(input, "Command");
	}
}