package stringProcessors;

@SuppressWarnings("serial")
public class ASemanticException extends java.io.IOException
{
	public ASemanticException(String inputError)
	{
		super(inputError);
	}
}
