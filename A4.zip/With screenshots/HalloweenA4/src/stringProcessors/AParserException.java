package stringProcessors;

@SuppressWarnings("serial")
public class AParserException extends java.io.IOException
{
	public AParserException(String inputError)
	{
		super(inputError);
	}
}
