package stringProcessors;

public class Move extends Word
{
	public Move(String input)
	{
		super(input, "Command");
	}
}