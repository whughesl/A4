package main;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.rmi.Remote;
import java.rmi.RemoteException;

import util.annotations.Tags;
import util.tags.DistributedTags;
@Tags({DistributedTags.SERVER_REMOTE_INTERFACE, DistributedTags.RMI})

public interface ServerInterface extends Remote{
	public void processArgs(String[] args) throws RemoteException;
	public void start() throws RemoteException;
	public void addPropertyChangeListener(PropertyChangeListener clientCoupler) throws RemoteException;
	public void notifyListeners(PropertyChangeEvent event) throws RemoteException;
	public void newCommand(String command, ClientInterface client) throws RemoteException;
	void addClient(ClientInterface client) throws RemoteException;
}
