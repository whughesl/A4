package main;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

import assignments.util.mainArgs.ServerArgsProcessor;
import util.annotations.Tags;
import util.tags.DistributedTags;
import util.trace.factories.FactoryTraceUtility;
import util.trace.misc.ThreadDelayed;
import util.trace.port.PortTraceUtility;
import util.trace.port.consensus.ConsensusTraceUtility;
import util.trace.port.nio.NIOTraceUtility;
import util.trace.port.rpc.rmi.RMIObjectRegistered;
import util.trace.port.rpc.rmi.RMIRegistryLocated;
import util.trace.port.rpc.rmi.RMITraceUtility;
@Tags({DistributedTags.SERVER, DistributedTags.RMI})

public class ServerMain {
	
	public static void main(final String[] args) {
		
//		PortTraceUtility.setTracing();
//		RMITraceUtility.setTracing();
//		NIOTraceUtility.setTracing();
//		FactoryTraceUtility.setTracing();		
//		ConsensusTraceUtility.setTracing();
//		ThreadDelayed.enablePrint();
		final ServerMain tracer = new ServerMain();
		try {
			final int registryPort = ServerArgsProcessor.getRegistryPort(args);
			final int serverPort = ServerArgsProcessor.getServerPort(args);
			final String host = ServerArgsProcessor.getRegistryHost(args);
			final java.rmi.registry.Registry registry = LocateRegistry.getRegistry(registryPort);
//			final String name = ServerArgsProcessor.getServerName(args);
			tracer.traceLocated(host, registryPort, registry);
			final ServerInterface server = new ServerObject();
			UnicastRemoteObject.exportObject(server, serverPort);
			registry.rebind(ServerInterface.class.getName(), server);
			tracer.traceRegistered(server, registry);
			server.start();
			
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
	}
	public void traceLocated(String aHost, int aPort, java.rmi.registry.Registry registry) {
		RMIRegistryLocated.newCase(this, aHost, aPort, registry);
	}
	public void traceRegistered( ServerInterface server, java.rmi.registry.Registry registry) {
		RMIObjectRegistered.newCase(this, "Server", server, registry);
	}

}
