package main;

import java.rmi.registry.Registry;

public interface ClientMainInterface {

	void traceLookUp(ServerInterface server, String serverName, Registry registry);

	void traceLocated(String aHost, int aPort, Registry registry);

}
