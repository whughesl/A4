package main;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;



import assignments.util.mainArgs.ClientArgsProcessor;
import util.annotations.Tags;
import util.tags.DistributedTags;
import util.trace.factories.FactoryTraceUtility;
import util.trace.misc.ThreadDelayed;
import util.trace.port.PortTraceUtility;
import util.trace.port.consensus.ConsensusTraceUtility;
import util.trace.port.nio.NIOTraceUtility;
import util.trace.port.rpc.rmi.RMIObjectLookedUp;
import util.trace.port.rpc.rmi.RMIRegistryLocated;
import util.trace.port.rpc.rmi.RMITraceUtility;
@Tags({DistributedTags.CLIENT, DistributedTags.RMI})

public class ClientMain implements ClientMainInterface{
	
	
	public static void main(final String[] args) {
//		PortTraceUtility.setTracing();
//		RMITraceUtility.setTracing();
//		NIOTraceUtility.setTracing();
//		FactoryTraceUtility.setTracing();		
//		ConsensusTraceUtility.setTracing();
//		ThreadDelayed.enablePrint();
		final ClientMain tracer = new ClientMain();
		try {
			final int registryPort = ClientArgsProcessor.getRegistryPort(args);
			final int serverPort = ClientArgsProcessor.getServerPort(args);
			final String registryHost = ClientArgsProcessor.getRegistryHost(args);
			final String clientName = ClientArgsProcessor.getClientName(args);
			final java.rmi.registry.Registry registry = LocateRegistry.getRegistry(registryPort);
			tracer.traceLocated(registryHost, registryPort, registry);
			final ServerInterface server = (ServerInterface) registry.lookup(ServerInterface.class.getName());
			tracer.traceLookUp(server, clientName, registry);
			final ClientInterface client = new ClientObject(server);
			
			client.init(args);
			client.start();
			
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (NotBoundException e) {
			e.printStackTrace();
		}
	}
	@Override
	public void traceLookUp(final ServerInterface server, final String serverName, final java.rmi.registry.Registry registry) {
		RMIObjectLookedUp.newCase(this, server, serverName, registry);
	}
	@Override
	public void traceLocated(final String aHost, final int aPort, final java.rmi.registry.Registry registry) {
		RMIRegistryLocated.newCase(this, aHost, aPort, registry);
	}
}
