package main;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.Serializable;
import java.rmi.RemoteException;

import stringProcessors.HalloweenCommandProcessor;
import util.annotations.Tags;
import util.tags.DistributedTags;
import util.trace.port.consensus.ProposalLearnedNotificationReceived;
import util.trace.port.consensus.communication.CommunicationStateNames;
import util.trace.trickOrTreat.LocalCommandObserved;
@Tags({DistributedTags.CLIENT_OUT_COUPLER, DistributedTags.RMI})

public class ClientOutCoupler implements PropertyChangeListener, Serializable {
	HalloweenCommandProcessor observingSimulation;
	ClientInterface observedClient;
	ServerInterface observedServer;
	public ClientOutCoupler(final HalloweenCommandProcessor anObservingSimulation , ClientInterface client, ServerInterface server) {
		observingSimulation = anObservingSimulation;
		observedClient = client;
		observedServer = server;
	}
	
	@Override
	public void propertyChange(final PropertyChangeEvent event) {
//		ProposalLearnedNotificationReceived.newCase(this, CommunicationStateNames.COMMAND, -1, event.getNewValue());
//		if(observingSimulation.isConnectedToSimulation() && event.getPropertyName().equals("InputString")) {
//			final String command = (String) event.getNewValue();
//			LocalCommandObserved.newCase(this, command);
//			observingSimulation.processCommand(command); // THis is not the client, its just the halloween processor.
//			try {
//				observedClient.processCommand(command);
//			} catch (RemoteException e) {
//			
//				e.printStackTrace();
//			}
//		}
		
	}
	
	public void commandRecieved(String command) {
		if(observingSimulation.isConnectedToSimulation()) {
			try {
				observedServer.newCommand(command, observedClient);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
