package main;

import java.rmi.Remote;
import java.rmi.RemoteException;

import util.annotations.Tags;
import util.tags.DistributedTags;
@Tags({DistributedTags.CLIENT_REMOTE_INTERFACE, DistributedTags.RMI})

public interface ClientInterface extends Remote{
	public void processArgs(String[] args) throws RemoteException;
	public void start() throws RemoteException;
	public void init(String [] args) throws RemoteException;
	void newCommand(String command) throws RemoteException;
}
