package main;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.Serializable;
import java.rmi.RemoteException;

import assignments.util.inputParameters.AnAbstractSimulationParametersBean;
import assignments.util.mainArgs.ClientArgsProcessor;
import stringProcessors.HalloweenCommandProcessor;
import util.annotations.Tags;
import util.interactiveMethodInvocation.SimulationParametersControllerFactory;
import util.misc.ThreadSupport;
import util.tags.DistributedTags;
import util.trace.Tracer;
import util.trace.factories.FactoryTraceUtility;
import util.trace.misc.ThreadDelayed;
import util.trace.port.PerformanceExperimentEnded;
import util.trace.port.PerformanceExperimentStarted;
import util.trace.port.PortTraceUtility;
import util.trace.port.consensus.ConsensusTraceUtility;
import util.trace.port.consensus.ProposalLearnedNotificationReceived;
import util.trace.port.nio.NIOTraceUtility;
import util.trace.port.rpc.rmi.RMITraceUtility;
import util.trace.port.consensus.ProposalMade;
import util.trace.port.consensus.ProposedStateSet;
import util.trace.port.consensus.RemoteProposeRequestSent;
import util.trace.port.consensus.communication.CommunicationStateNames;
@Tags({DistributedTags.CLIENT_REMOTE_OBJECT, DistributedTags.RMI})

public class ClientObject extends AnAbstractSimulationParametersBean implements ClientInterface, PropertyChangeListener, Serializable {
	HalloweenCommandProcessor simulation;
	protected ClientOutCoupler clientCoupler;
	ServerInterface server;
	
	public static final int NUM_EXPERIMENT_COMMANDS = 500;
	public static final String EXPERIMENT_COMMAND_1 = "move 1 -1";
	public static final String EXPERIMENT_COMMAND_2 = "undo";
	
	public ClientObject(final ServerInterface remoteServer) {
		server = remoteServer;
		setTracing();
	}
	
	@Override //I dont think this is right. Coupler is calling process command on simulation already
	public void newCommand(final String command) {
		ProposalLearnedNotificationReceived.newCase(this, CommunicationStateNames.COMMAND, -1, command);
		ProposedStateSet.newCase(this, CommunicationStateNames.COMMAND, -1, command);
		simulation.processCommand(command);
	}

	@Override
	public void processArgs(final String[] args) throws RemoteException {
		System.setProperty("java.awt.headless", ClientArgsProcessor.getHeadless(args));

	}

	@Override
	public void start(){
		//"after initializing the instance" <- does this mean after initializing the Halloween code?
		SimulationParametersControllerFactory.getSingleton().addSimulationParameterListener(this);
		SimulationParametersControllerFactory.getSingleton().processCommands();	
		
	}



	@Override
	public void init(final String[] args) throws RemoteException {
//		setTracing();
		processArgs(args);
		simulation = BeauAndersonFinalProject.createSimulation("1:", 0, 0, 400, 765, 0, 0);
		clientCoupler = new ClientOutCoupler(simulation, this, server);
//		server.addPropertyChangeListener(clientCoupler);
		server.addClient(this);
		simulation.addPropertyChangeListener(this);
	}
	
	protected void setTracing() {
		PortTraceUtility.setTracing();
		RMITraceUtility.setTracing();
		NIOTraceUtility.setTracing();
		FactoryTraceUtility.setTracing();		
		ConsensusTraceUtility.setTracing();
		ThreadDelayed.enablePrint();
		trace(true);
	}



	@Override
	public void propertyChange(final PropertyChangeEvent event) {
//		try {
//			ProposalMade.newCase(event.getNewValue(), this, "idk the name", 1.0000, CommunicationStateNames.COMMAND);
			ProposalMade.newCase(this, CommunicationStateNames.COMMAND, -1, event.getNewValue());
			final long aDelay = getDelay(); 
			if (aDelay > 0) {
				ThreadSupport.sleep(aDelay);
			}
			RemoteProposeRequestSent.newCase(this,CommunicationStateNames.COMMAND, -1, event.getNewValue());
			clientCoupler.commandRecieved((String)event.getNewValue());
			
//			server.newCommand((String)event.getNewValue());
			

//		} catch (RemoteException error) {	
//			error.printStackTrace();
//		}
		
	}
	public void quit(final int aCode) {
		System.exit(aCode);
	}	
	@Override
	/*
	 * You will need to delay not command input but sends(non-Javadoc)
	 */
	public void simulationCommand(final String aCommand) {
//		ProposedStateSet.newCase(this, CommunicationStateNames.COMMAND, -1, aCommand);
		simulation.setInputString(aCommand); // all commands go to the first command window
	}
	@Override	
	public void trace(final boolean newValue) {
		super.trace(newValue);
		Tracer.showInfo(isTrace());
	}
	@Override
	public void localProcessingOnly(final boolean newValue) {
		super.localProcessingOnly(newValue);
		if (isLocalProcessingOnly()) {
//			simulation.removePropertyChangeListener(simulation2Coupler);
//			commandProcessor2.removePropertyChangeListener(simulation1Coupler);
			System.out.println("===================================");
		} else {
//			commandProcessor1.addPropertyChangeListener(simulation2Coupler);
//			commandProcessor2.addPropertyChangeListener(simulation1Coupler);
			System.out.println("==================================");
		}
	}
	@Override
	/**
	 * Relevant in consistency assignments only 
	 */
	public void atomicBroadcast(final boolean newValue) {
		super.atomicBroadcast(newValue);
		simulation.setConnectedToSimulation(!isAtomicBroadcast());
	}
	@Override
	public void experimentInput() {
		final long aStartTime = System.currentTimeMillis();
		PerformanceExperimentStarted.newCase(this, aStartTime, NUM_EXPERIMENT_COMMANDS);
		final boolean anOldValue = isTrace();
		this.trace(false);
		for (int i = 0; i < NUM_EXPERIMENT_COMMANDS; i++) {
			simulation.setInputString(EXPERIMENT_COMMAND_1);
			simulation.setInputString(EXPERIMENT_COMMAND_2);
		}
		trace(anOldValue);
		final long anEndTime = System.currentTimeMillis();
		PerformanceExperimentEnded.newCase(this, aStartTime, anEndTime, anEndTime - aStartTime, NUM_EXPERIMENT_COMMANDS);
		
	}
	@Override
	/*
	 * This override is not really needed, provided here to show that this method
	 * exists.
	 */
	public void delaySends(final int aMillisecondDelay) {
		// invoke setDelaySends so getDelaySends can be used to determine the delay
		// in other parts of the program
		super.delaySends(aMillisecondDelay);
	}
	
}
