package stringProcessors;

public interface TokenInterface
{
	public String getUserInputString();
	public String getTokenType();
	public String toString();
}