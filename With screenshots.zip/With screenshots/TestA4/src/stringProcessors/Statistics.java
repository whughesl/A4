package stringProcessors;

public class Statistics extends Word
{
	public Statistics(String input)
	{
		super(input, "Command");
	}
}