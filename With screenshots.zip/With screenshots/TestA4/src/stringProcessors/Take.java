package stringProcessors;

public class Take extends Word
{
	public Take(String input)
	{
		super(input, "Command");
	}
}