package stringProcessors;

public interface NumberInterface extends TokenInterface
{
	public int convertToInt();
}
