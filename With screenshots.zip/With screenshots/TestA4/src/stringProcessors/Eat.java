package stringProcessors;

public class Eat extends Word
{
	public Eat(String input)
	{
		super(input, "Command");
	}
}