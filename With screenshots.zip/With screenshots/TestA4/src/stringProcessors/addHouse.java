package stringProcessors;

public class addHouse extends Word
{
	public addHouse(String input)
	{
		super(input, "Command");
	}
}