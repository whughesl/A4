package main;


import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import util.annotations.Tags;
import util.tags.DistributedTags;
import util.trace.factories.FactoryTraceUtility;
import util.trace.misc.ThreadDelayed;
import util.trace.port.PortTraceUtility;
import util.trace.port.consensus.ConsensusTraceUtility;
import util.trace.port.nio.NIOTraceUtility;
import util.trace.port.rpc.rmi.RMIRegistryCreated;
import util.trace.port.rpc.rmi.RMITraceUtility;
import assignments.util.mainArgs.RegistryArgsProcessor;

@Tags({DistributedTags.REGISTRY, DistributedTags.RMI})

public class RegistryHalloween {
	
	public static void main(final String[] args) {
		final RegistryHalloween registry = new RegistryHalloween();
		PortTraceUtility.setTracing();
		RMITraceUtility.setTracing();
		NIOTraceUtility.setTracing();
		FactoryTraceUtility.setTracing();		
		ConsensusTraceUtility.setTracing();
		ThreadDelayed.enablePrint();
		
		try {
			final int registryPort = RegistryArgsProcessor.getRegistryPort(args);
			LocateRegistry.createRegistry(registryPort);
			registry.traceCreated(registryPort);
//			RMIRegistryCreated.newCase(this, registryPort);
			while(true) {
				//
			}	
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	public void traceCreated(final int port) {
		RMIRegistryCreated.newCase(this, port);
	}

}
