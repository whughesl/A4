package main;

import grader.basics.execution.BasicProjectExecution;
import gradingTools.comp533s21.assignment4.S21Assignment4Suite;
import trace.grader.basics.GraderBasicsTraceUtility;

public class RunA4Tests {
	final static int MAX_PRINTED_TRACES = 1000;
	final static int MAX_TRACES = 2000;
	final static int PROCESS_TIME_OUT = 5;
	public static void main(final String[] args) {
		
		// if you set this to false, grader steps will not be traced
		GraderBasicsTraceUtility.setTracerShowInfo(true);	
		// if you set this to false, all grader steps will be traced,
		// not just the ones that failed		
		GraderBasicsTraceUtility.setBufferTracedMessages(false);
		// Change this number if a test trace gets longer than 600 and is clipped
		GraderBasicsTraceUtility.setMaxPrintedTraces(MAX_PRINTED_TRACES);
		// Change this number if all traces together are longer than 2000
		GraderBasicsTraceUtility.setMaxTraces(MAX_TRACES);
		// Change this number if your process times out prematurely
		BasicProjectExecution. setProcessTimeOut(PROCESS_TIME_OUT);
		// You need to always call such a method
		S21Assignment4Suite.main(args);
	}
}
