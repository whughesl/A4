package main;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import assignments.util.inputParameters.AnAbstractSimulationParametersBean;
import assignments.util.mainArgs.ClientArgsProcessor;
import util.annotations.Tags;
import util.interactiveMethodInvocation.SimulationParametersControllerFactory;
import util.misc.ThreadSupport;
import util.tags.DistributedTags;
import util.trace.port.consensus.RemoteProposeRequestReceived;
import util.trace.port.consensus.ProposalLearnedNotificationSent;
import util.trace.port.consensus.communication.CommunicationStateNames;
@Tags({DistributedTags.SERVER_REMOTE_OBJECT, DistributedTags.RMI})

public class ServerObject extends AnAbstractSimulationParametersBean implements ServerInterface {
	List<PropertyChangeListener> listeners = new ArrayList<PropertyChangeListener>();
	List<ClientInterface> clients = new ArrayList<ClientInterface>();
	BlockingQueue<String> commands = new ArrayBlockingQueue<String>(5); //try later
	String inputString = "";
	@Override
	public void processArgs(final String[] args){
		System.setProperty("java.awt.headless", ClientArgsProcessor.getHeadless(args));
		
		
	}
	@Override
	public void newCommand(final String command, ClientInterface client) {
		if(command.equals("")) {
			return;
		}
		RemoteProposeRequestReceived.newCase(this, CommunicationStateNames.COMMAND, -1, command);
		final String oldString = inputString;
		
		inputString = command;
		
		for (int counter = clients.size()-1; counter >= 0; counter--) { 	
//			if(clients.get(counter) != client) {
				try {
					final long aDelay = getDelay(); 
					if (aDelay > 0) {
						ThreadSupport.sleep(aDelay);
					}
					ProposalLearnedNotificationSent.newCase(this, CommunicationStateNames.COMMAND, -1, command);
					clients.get(counter).newCommand(command);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}		
//			}
	          
	      }  
	}

	@Override
	public void start() {
		SimulationParametersControllerFactory.getSingleton().addSimulationParameterListener(this);
		SimulationParametersControllerFactory.getSingleton().processCommands();	
		
	}


	
	@Override
	public void addClient(final ClientInterface client) {
		clients.add(client);
	}
	@Override
	public void notifyListeners(final PropertyChangeEvent event) {
		ProposalLearnedNotificationSent.newCase(this, CommunicationStateNames.COMMAND, -1, event.getNewValue());
		for (int counter = 0; counter < listeners.size(); counter++) { 		      
//	          listeners.get(counter).propertyChange(event);		
	      }  
	}
	@Override
	public void addPropertyChangeListener(PropertyChangeListener clientCoupler){
		listeners.add(clientCoupler);
		
	}
	@Override
	public void delaySends(final int aMillisecondDelay) {
		// invoke setDelaySends so getDelaySends can be used to determine the delay
		// in other parts of the program
		super.delaySends(aMillisecondDelay);
	}
	
}
