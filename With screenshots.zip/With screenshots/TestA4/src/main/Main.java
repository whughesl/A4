package main;
import main.BeauAndersonFinalProject;
public class Main {
	public static void main(String[] args) {
		BeauAndersonFinalProject.main(args);
	}
}

// observer interface for which user commands are generated: assignments.util.inputParameters.SimulationParametersListener
//library calls methods in 

// each client will only have one command model. Its effect will be to change both simulations in 
// all clients (of the server)

//You should change the implementation to delay sending of the command to remote processes via the broadcast server.
// using d(elaySends) int

//you can use "e" to test performance (500 simulation commands) in the client
// but make sure to disable tracing

//change some ish about "l", decouples sims?

//a true -> unsyncs

// q(uit) int is the only command the server processes

// As the template code does, create classes for both the server and client that 
// 	subclasses AnAbstractSimulationParametersBean
// Client and server mains should create instances of these classes
// these should define a start instance method that, after initializing the instance, 
//  invokes the addSimulationParameterListener and 

//stringProcessors.HalloweenCommandProcessor void processCommand(string) must be invoked in response to 
// other remote processes

//traces will be in util.trace.port.rpc.rmi/ util.trace.port.consensus