package main;

import util.annotations.Tags;
import util.tags.DistributedTags;
@Tags({DistributedTags.SERVER_CONFIGURER, DistributedTags.RMI})

public class ServerConfigurer {

}
