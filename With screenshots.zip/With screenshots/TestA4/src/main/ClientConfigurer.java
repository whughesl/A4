package main;

import util.annotations.Tags;
import util.tags.DistributedTags;
@Tags({DistributedTags.CLIENT_CONFIGURER, DistributedTags.RMI})

public class ClientConfigurer {
	//Object that crates the main mehtod?
	
}
